$(function($) { // Image SVG
    function imgSVG() {
        $('img.svg').each(function() {
            var $img = $(this);
            var imgID = $img.attr('id');
            var imgClass = $img.attr('class');
            var imgURL = $img.attr('src');
            $.get(imgURL, function(data) { // Get the SVG tag, ignore the rest
                var $svg = $(data).find('svg'); // Add replaced image's ID to the new SVG
                if (typeof imgID !== 'undefined') {
                    $svg = $svg.attr('id', imgID)
                } // Add replaced image's classes to the new SVG
                if (typeof imgClass !== 'undefined') {
                    $svg = $svg.attr('class', imgClass + ' replaced-svg')
                } // Remove any invalid XML tags as per http://validator.w3.org
                $svg = $svg.removeAttr('xmlns:a'); // Replace image with new SVG
                $img.replaceWith($svg)
            }, 'xml')
        })
    } // grab the initial top offset of the navigation 
    var stickyNavTop = $('.navbar__content').offset().top;
    var stickyNav = function() {
        var scrollTop = $(window).scrollTop();
        if (scrollTop > stickyNavTop) {
            $('.navbar__content').addClass('sticky');
            $('.navbar__top').addClass('sticky')
        } else {
            $('.navbar__content').removeClass('sticky');
            $('.navbar__top').removeClass('sticky')
        }
        $('.navbar-nav li').each(function() {
            if ($(this).hasClass('active')) {
                var parent = $(this).parents('.hasChild');
                if (!parent.hasClass('active')) {
                    parent.addClass('active')
                }
            }
        })
    };
    $expand = $('.expand');
    $expand.click(function() {
        el = $(this);
        elContent = el.next('ul'), allContent = el.parent('li').parent('ul').children('li').children('ul'), allExpand = allContent.prev('.expand');
        if (el.hasClass('active')) {
            el.removeClass('active');
            elContent.stop().slideUp(200)
        } else {
            allContent.stop().slideUp(200);
            allExpand.removeClass('active');
            el.addClass('active');
            elContent.stop().slideDown(200)
        }
    }); // Search Form
    function search() {
        var $searchBtn = $('.navbar__search__btn');
        var $searchWrap = $searchBtn.parent('.navbar__search');
        var $nav = $('.navbar-collapse');
        $searchBtn.click(function(e) {
            e.stopPropagation();
            if ($searchWrap.hasClass('active')) {
                $nav.removeClass('search-active');
                $searchWrap.removeClass('active').delay(100).queue(function(next) {
                    $searchWrap.find('.navbar__search__form').fadeOut(100);
                    next()
                })
            } else {
                $nav.addClass('search-active');
                $searchWrap.find('.navbar__search__form').fadeIn(100).delay(100).queue(function(next) {
                    $searchWrap.addClass('active');
                    $searchWrap.find('input[type="text"]')[0].focus();
                    next()
                })
            }
        });
        $searchWrap.click(function(e) {
            e.stopPropagation()
        });
        $(document).click(function(event) {
            if (!$(event.target).hasClass('navbar__search')) {
                $nav.removeClass('search-active');
                $searchWrap.removeClass('active').delay(100).queue(function(next) {
                    $searchWrap.find('.navbar__search__form').fadeOut(100);
                    next()
                })
            }
        })
    } // Select Form
    function select() {
        var chosenE = $('select.select');
        if (chosenE.length > 0) {
            chosenE.chosen({
                'disable_search': true
            });
            chosenE.each(function() {
                if ($(this).attr('required') !== undefined) {
                    $(this).on('change', function() {
                        $(this).valid()
                    })
                }
            })
        }
        $('.chosen-results, .list').niceScroll({
            cursorcolor: 'rgba(177,180,193,0.5)',
            cursorwidth: '4px',
            background: 'rgba(226,226,226,0.5)',
            cursorborder: 'none',
            cursorborderradius: '2px'
        })
    }

    function btnShadow() {
        var btn = $('button.btn-shadow, a.btn-shadow');
        btn.each(function() {
            var el = $(this);
            el.addClass('btn-shadowjs').wrapInner('<span class="text"></span>')
        })
    }

    function valiForm() {
        $.validator.setDefaults({
            ignore: ':hidden:not(select)'
        });
        $valiForm = $('form.validate');
        if ($valiForm.length > 0) {
            $valiForm.each(function() {
                var el = $(this),
                    id = el.attr('id');
                $('#' + id).validate({
                    errorPlacement: function(error, element) {
                        if (element.is('select.select')) { // placement for chosen
                            error.insertAfter(element.next('div.chosen-container'))
                        } else { // standard placement
                            error.insertAfter(element)
                        }
                    }
                })
            })
        }
        var subject = $('#subject');
        subject.change(function() {
            var el = $(this),
                val = el.val();
            console.log(val);
            if (val == 'other') {
                el.parents('.form-group').find('input.form-control').show();
                el.parents('.form-group').find('.form-group__back').show()
            }
        });
        $(document).on('click', '.form-group__back', function(e) {
            var el = $(this);
            e.preventDefault();
            subject.val($('#subject option:first').val());
            subject.trigger('chosen:updated');
            el.parents('.form-group').find('input.form-control').hide();
            el.parents('.form-group').find('.form-group__back').hide()
        })
    }

    function valiCareerApply() {
        $('#careerApply').validate({});
        $('.brithday-control').change(function() {
            $('#applydate').valid()
        })
    }

    function labelForm() {
        var fGroup = $('.form-group');
        fGroup.each(function() {
            var el = $(this),
                input = el.find('.form-control'),
                value = input.val();
            if (value) {
                input.attr('data-value', 'true')
            } else {
                input.attr('data-value', 'false')
            }
            input.on('input', function() {
                var _el = $(this),
                    _value = _el.val();
                if (_value) {
                    _el.attr('data-value', 'true')
                } else {
                    _el.attr('data-value', 'false')
                }
            })
        });
        var fileGroup = $('.file-group');
        fileGroup.each(function() {
            var el = $(this);
            el.find('input[type="file"]').change(function(e) {
                var fileName = e.target.files[0].name;
                el.find('.form-control > label').text(fileName)
            })
        })
    }

    function faqTabs() {
        var nav = $('.joinCultureContact__accordion .quick--link a');
        content = $('.joinCultureContact__accordion .panel-group');
        flag = 0;
        nav.click(function(e) {
            var el = $(this),
                elLi = el.parent('li'),
                elContent = $(el.attr('href'));
            e.preventDefault();
            if (!elLi.hasClass('active')) {
                nav.parent('li').removeClass('active');
                content.removeClass('active');
                elLi.addClass('active');
                checkEq(elLi.index());
                console.log(flag);
                elContent.addClass('active').removeClass('flyleft').removeClass('flyright')
            }
        });

        function checkEq(i) {
            content.each(function() {
                var el = $(this);
                if (el.index() < i) {
                    el.addClass('flyleft')
                } else {
                    el.addClass('flyright')
                }
            })
        }
    }

    function mainBanner() {
        var $banner = $('.banner__content');
        if ($banner.length) {
            $banner.on('init', function(event, slick) {
                $banner.find('.slick-dots').wrap('<div class="banner__content__dots"><div class="container"></div></div>')
            }).slick({
                slidesToShow: 1,
                slidesToScroll: 1,
                arrows: true,
                prevArrow: '<a class="arrow arrow--prev" href="#"></a>',
                nextArrow: '<a class="arrow arrow--next" href="#"></a>',
                fade: true,
                cssEase: 'linear',
                dots: true
            })
        }
    }

    function careerDetail() {
        $('#careerDetail').on('show.bs.modal', function(event) {
            var button = $(event.relatedTarget);
            var title = button.data('title'),
                location = button.data('location'),
                link = button.data('link'),
                time = button.data('time'),
                salary = button.data('salary'),
                number = button.data('number'),
                form = button.data('form'),
                workingtime = button.data('workingtime'),
                experience = button.data('experience'),
                position = button.data('position'),
                desc = button.data('desc'),
                request = button.data('request'),
                benefit = button.data('benefit');
            var modal = $(this);
            modal.find('.careerDetail__title').text(title);
            modal.find('.careerDetail__location').text(location);
            modal.find('.careerDetail__time').text(time);
            modal.find('.careerDetail__salary').text(salary);
            modal.find('.careerDetail__number').text(number);
            modal.find('.careerDetail__form').text(form);
            modal.find('.careerDetail__workingtime').text(workingtime);
            modal.find('.careerDetail__experience').text(experience);
            modal.find('.careerDetail__position').text(position);
            modal.find('.careerDetail__desc').html(desc);
            modal.find('.careerDetail__request').html(request);
            modal.find('.careerDetail__benefit').html(benefit);
            modal.find('.careerDetail__footer a').attr({
                'href': link
            })
        })
    }

    function goTo() {
        var linkScroll = $('.scrollBottom');
        linkScroll.bind('click', function(event) {
            var el = $(this);
            event.preventDefault();
            var elementTo = $($(event.target).attr('href'));
            $('html, body').animate({
                scrollTop: elementTo.offset().top - 50
            }, 600)
        })
    }

    function checkHash() {
        var hash = window.location.hash;
        if (hash !== '') {
            var elementTo = $(hash);
            $('html, body').animate({
                scrollTop: elementTo.offset().top - 50
            }, 600)
        }
    }

    function customers() {
        $customers = $('.customers__inner');
        $customersBG = $('.ourCustomers__bg__item');
        $customersAvatar = $('.ourCustomers__avatar__item');
        if ($customers.length) {
            $customers.slick({
                slidesToShow: 1,
                slidesToScroll: 1,
                arrows: true,
                prevArrow: '<a class="hidden" href="#"></a>',
                nextArrow: '<a class="arrow arrow--next" href="#"><i class="arrow_carrot-right"></i></a>',
                fade: true,
                cssEase: 'linear',
                dots: true // adaptiveHeight: true
            }).on('beforeChange', function(event, slick, currentSlide, nextSlide) {
                $customersBG.removeClass('active');
                $customersAvatar.removeClass('active');
                $customersBG.eq(nextSlide).addClass('active');
                $customersAvatar.eq(nextSlide).addClass('active')
            })
        }
    }

    function parallaxBG() {
        $('[data-paroller-factor]').paroller()
    }

    function waypointEl() {
        var way = $('[data-waypoint]');
        way.each(function() {
            var _el = $(this),
                _ofset = _el.data('waypoint'),
                _up = _el.data('waypointup');
            _el.waypoint(function(direction) {
                if (direction == 'down') {
                    _el.addClass('active')
                } else {
                    if (_up) {
                        _el.removeClass('active')
                    }
                }
            }, {
                offset: _ofset
            })
        })
    }

    function animateEffect() {
        var way = $('[data-animated-effect]');
        way.addClass('animated').waypoint({
            offset: '70%',
            triggerOnce: true,
            handler: function() {
                var el = $(this.element).length ? $(this.element) : $(this);
                el.each(function(i, elem) {
                    var elem = $(elem),
                        type = $(this).data('animated-effect'),
                        delay = $(this).data('animated-delay');
                    setTimeout(function() {
                        elem.addClass(type)
                    }, delay)
                });
                if (typeof this.destroy !== 'undefined' && $.isFunction(this.destroy)) {
                    this.destroy()
                }
            }
        })
    }

    function gotoTop() {
        var topTop = $('.toTop');
        topTop.click(function() {
            $('body,html').animate({
                scrollTop: 0
            }, 500);
            return false
        })
    } //Slider Executive 
    function sliderExecutive() {
        var exePeople = $('.exePeople'),
            exePeopleDesc = $('.exePeopleDesc'),
            people = $('.exePeople__item');
        exePeople.on('init', function(event, slick, direction) {
            exePeople.find('[data-slick-index="0"]').find('.exePeople__item').addClass('active');
            arrowAdd();
            arrowLoad()
        }).slick({
            slidesToShow: 3,
            slidesToScroll: 3,
            adaptiveHeight: false,
            dots: false,
            arrows: true, // infinite: false,
            prevArrow: '<a class="arrow-1 arrow--prev" href="#"><i class="arrow_carrot-left"></i></a>',
            nextArrow: '<a class="arrow-1 arrow--next" href="#"><i class="arrow_carrot-right"></i></a>',
            responsive: [{
                breakpoint: 992,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2
                }
            }, {
                breakpoint: 576,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }]
        }).on('breakpoint', function(event, slick, direction) {
            arrowAdd();
            arrowLoad()
        }).on('afterChange', function(event, slick, currentSlide) {
            exePeople.find('.exePeople__item').removeClass('active');
            exePeople.find('[data-slick-index="' + currentSlide + '"]').find('.exePeople__item').addClass('active');
            arrowLoad();
            gotoDesc(currentSlide)
        });
        exePeopleDesc.slick({
            slidesToShow: 1,
            slidesToScroll: 1,
            arrows: false,
            adaptiveHeight: true,
            speed: 100,
            fade: true,
            cssEase: 'linear',
            touchMove: false,
            swipe: false
        });

        function arrowAdd() {
            exePeople.find('.slick-track').append('<span class="exePeople__arrow"></span>')
        }

        function arrowLoad() {
            var arrow = $('.exePeople__arrow');
            arrow.width(exePeople.find('.slick-slide').outerWidth()).css('left', $('.exePeople__item.active').parents('.slick-slide').position().left);
            exePeople.on('click', '.exePeople__item', function() {
                var el = $(this);
                if (!el.hasClass('active')) {
                    people.removeClass('active');
                    el.addClass('active')
                }
                gotoDesc(el.parents('.slick-slide').data('slick-index'));
                var newWidth = exePeople.find('.slick-slide').outerWidth();
                var leftPos = el.parents('.slick-slide').position().left;
                var arrow = $('.exePeople__arrow');
                arrow.width(newWidth).css('left', leftPos)
            })
        }

        function gotoDesc(index) {
            exePeopleDesc.slick('slickGoTo', index)
        }
    } //Slider why 
    function sliderWhy() {
        $('.sliderFor').slick({
            slidesToShow: 1,
            slidesToScroll: 1,
            arrows: false, //fade: true,
            adaptiveHeight: true,
            asNavFor: '.sliderNav'
        });
        $('.sliderNav').slick({
            slidesToShow: 3,
            slidesToScroll: 1,
            asNavFor: '.sliderFor',
            adaptiveHeight: false,
            dots: false,
            arrows: false,
            focusOnSelect: true,
            responsive: [{
                breakpoint: 640,
                settings: {
                    arrows: true,
                    prevArrow: '<a class="arrow-1 arrow--prev" href="#"><i class="arrow_carrot-left"></i></a>',
                    nextArrow: '<a class="arrow-1 arrow--next" href="#"><i class="arrow_carrot-right"></i></a>',
                    slidesToShow: 2,
                    slidesToScroll: 1
                }
            }]
        }).on('setPosition', function(event, slick) {
            slick.$slides.find('.sliderNavItem').css('height', slick.$slideTrack.height() + 'px')
        })
    } //Slider Staff
    function sliderStaff() {
        $('#staffSlider').slick({
            slidesToShow: 3,
            slidesToScroll: 1,
            prevArrow: '<a class="arrow-1 arrow--prev" href="#"><i class="arrow_carrot-left"></i></a>',
            nextArrow: '<a class="arrow-1 arrow--next" href="#"><i class="arrow_carrot-right"></i></a>',
            dots: true,
            arrows: true,
            responsive: [{
                breakpoint: 570,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1
                }
            }]
        })
    } //slider popup people
    function sliderStaffPopup() {
        $('.popupSlider').slick({
            slidesToShow: 4,
            slidesToScroll: 1,
            prevArrow: '<a class="arrow-1 arrow--prev" href="#"><i class="arrow_carrot-left"></i></a>',
            nextArrow: '<a class="arrow-1 arrow--next" href="#"><i class="arrow_carrot-right"></i></a>',
            arrows: true,
            responsive: [{
                breakpoint: 800,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 1
                }
            }, {
                breakpoint: 640,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1
                }
            }]
        })
    } //slider news
    function sliderNews() {
        $('.gridNewsSlider').slick({
            slidesToShow: 3,
            prevArrow: '<a class="arrow-1 arrow--prev" href="#"><i class="arrow_carrot-left"></i></a>',
            nextArrow: '<a class="arrow-1 arrow--next" href="#"><i class="arrow_carrot-right"></i></a>',
            arrows: true,
            responsive: [{
                breakpoint: 800,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1
                }
            }, {
                breakpoint: 480,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }]
        })
    }

    function quoteFix() {
        var quote = $('.boxquote__content');
        if (quote.find('p').length) {
            quote.find('p:last-child').append('<span class="icon"></span>')
        } else {
            quote.append('<span class="icon"></span>')
        }
    }

    function accordionScroll() {} //Fix z-index Item hover
    function hoverFix() {
        $('.whyChoose__item, .priceTable__item').hover(function() {
            $('.whyChoose__item, .priceTable__item').removeClass('top');
            $(this).stop().addClass('top')
        }, function() {
            $(this).stop().addClass('out').delay(300).queue(function(next) {
                $(this).removeClass('out');
                next()
            })
        })
    } // FAQs Tabs
    function faqTabsCustome() {
        var nav = $('.faqs__desc__head');
        var content = $('.faqs__detail .panel-group');
        var head = $('.faqs__detail__head');
        nav.click(function() {
            var el = $(this);
            val = el.data('tab');
            text = el.text();
            var elContent = $('#' + val);
            if (!elContent.hasClass('active')) {
                $('html, body').animate({
                    scrollTop: $('.faqs__detail').offset().top - 100
                }, 600);
                head.text(text);
                content.removeClass('active');
                elContent.addClass('active')
            }
        })
    } // Method Tabs
    function methodTab() {
        var nav = $('.methodTab__nav li');
        var content = $('.methodTab__item');
        nav.click(function() {
            var el = $(this);
            val = el.index();
            var elContent = $('.methodTab__item').eq(val);
            if (!elContent.hasClass('active')) {
                nav.removeClass('active');
                el.addClass('active');
                content.removeClass('active');
                elContent.addClass('active')
            }
        })
    }

    function fiSolution() {
        var job = $('#fijob');
        var doc = $('#fidoc');
        var modalWarning01 = $('#warningFirstModal');
        var modalWarning02 = $('#warningModal');
        if (job.val() === '') {
            doc.prop('disabled', true);
            doc.trigger('chosen:updated')
        } else {
            doc.prop('disabled', false);
            doc.trigger('chosen:updated')
        } // Chọn combo giấy tờ
        var btn = $('.docs-modal'); // Hiển thị box chọn combo giấy tờ
        $('body').on('click', '.docs-modal + .chosen-container, .docs-modal', function(e) {
            e.preventDefault();
            if (job.val()) {
                $('#docsModal').modal('show')
            } else {
                modalWarning01.modal('show')
            }
        }); // Chọn combo
        $(document).on('click', '.docsTable .btn', function() {
            var el = $(this);
            var _val = el.data('val');
            btn.val(_val);
            btn.attr('data-value', 'true');
            btn.trigger('chosen:updated');
            $('.docsTable .btn').removeClass('active');
            el.addClass('active');
            if (el.hasClass('active')) {
                $('#docsModal').modal('hide')
            } // Kiểm tra select box giấy tờ
            vJob = job.val();
            if (vJob) {
                group.removeClass('disabled')
            } else {
                if (!group.hasClass('disabled')) {
                    group.addClass('disabled')
                }
            }
        }); // Kiểm tra bước 1 để kích hoạt bước 2
        var group = job.parents('.col-sm-10').next('.col-sm-10');
        job.change(function() {
            var el = $(this);
            vJob = el.val();
            vDoc = doc.val();
            if (vJob && vDoc) {
                group.removeClass('disabled')
            } else {
                if (!group.hasClass('disabled')) {
                    group.addClass('disabled')
                }
            }
        }); // Hiện thông báo nếu client chọn bước 2 trước bước 1
        $('div.disabled').click(function() {
            if ($(this).hasClass('disabled')) {
                modalWarning02.modal('show')
            }
        }); // Gọi hàm xử lý chọn khoản vay và thời hạn vay
        range()
    } // Range Form
    function range() {
        var $range = $('.form-range');
        if ($range.length) {
            function _muchYouNeed() {
                var $muchYouNeed = $('#much-you-need'),
                    dataPrefix = $muchYouNeed.data('prefix'),
                    dataMin = $muchYouNeed.data('min'),
                    dataMax = $muchYouNeed.data('max'),
                    dataFrom = $muchYouNeed.data('from'),
                    dataStep = $muchYouNeed.data('step');
                if (typeof dataPrefix === 'undefined') {
                    dataPrefix = ''
                }
                if (typeof dataMin === 'undefined') {
                    dataMin = 0
                }
                if (typeof dataMax === 'undefined') {
                    dataMax = 10
                }
                if (typeof dataFrom === 'undefined') {
                    dataFrom = 0
                }
                if (typeof dataStep === 'undefined') {
                    dataStep = 1
                }
                _ionRangeSlider($muchYouNeed, dataMin, dataMax, dataFrom, dataStep, dataPrefix)
            }

            function _paymentTerms() {
                var $paymentTerms = $('#payment-term'),
                    dataPrefix = $paymentTerms.data('prefix'),
                    dataMin = $paymentTerms.data('min'),
                    dataMax = $paymentTerms.data('max'),
                    dataFrom = $paymentTerms.data('from'),
                    dataStep = $paymentTerms.data('step');
                if (typeof dataPrefix === 'undefined') {
                    dataPrefix = ''
                }
                if (typeof dataMin === 'undefined') {
                    dataMin = 3
                }
                if (typeof dataMax === 'undefined') {
                    dataMax = 24
                }
                if (typeof dataFrom === 'undefined') {
                    dataFrom = 3
                }
                if (typeof dataStep === 'undefined') {
                    dataStep = 1
                }
                _ionRangeSlider($paymentTerms, dataMin, dataMax, dataFrom, dataStep, dataPrefix)
            }

            function _ionRangeSlider($el, dataMin, dataMax, dataFrom, dataStep, dataPrefix) {
                $el.ionRangeSlider({
                    min: dataMin,
                    max: dataMax,
                    from: dataFrom,
                    step: dataStep,
                    type: 'single',
                    prefix: dataPrefix,
                    hide_min_max: true,
                    hide_from_to: true,
                    force_edges: false,
                    grid: false,
                    onStart: function() {
                        var text = $el.parent('.form-range').find('.irs-slider.single');
                        text.text(dataPrefix);
                        _checkRange()
                    },
                    onChange: function(data) {
                        var val = $el.parent('.form-range').find('ins span');
                        val.text(prettify(data.from));
                        _checkRange()
                    }
                })
            }

            function prettify(num) {
                var n = num.toString();
                return n.replace(/(\d{1,3}(?=(?:\d\d\d)+(?!\d)))/g, '$1' + '.')
            }

            function _checkRange() {
                var month = $('#payment-term').val();
                var money = $('#much-you-need').val(); // Gọi hàm tính lãi
                // _calc(money, month);
            }

            function _calc(money, month) {
                var result = $('.fiSolution__divider b');
                var interest = 0.01; // Danh sách lãi xuất theo tháng: ở đây cũng là ví dụ
                switch (parseInt(month)) {
                    case 6:
                    case 7:
                    case 8:
                    case 9:
                    case 10:
                        interest = 0.01;
                        break;
                    case 11:
                    case 12:
                    case 13:
                    case 14:
                    case 15:
                        interest = 0.0115;
                        break;
                    case 16:
                    case 17:
                    case 18:
                    case 19:
                    case 20:
                        interest = 0.025;
                        break;
                    case 21:
                    case 22:
                    case 23:
                    case 24:
                    case 25:
                        interest = 0.035;
                        break;
                    case 26:
                    case 27:
                    case 28:
                    case 29:
                    case 30:
                        interest = 0.05;
                        break;
                    default:
                        interest = 0.07;
                } // Công thức tính khoản vay. tạm thời ví dụ là vậy
                var recipe = interest * money; // Xử lý để render ra HTML
                var temp = Number(recipe).toFixed(0);
                result.html(prettify(temp) + '<sup>\u0111</b>')
            }
            _muchYouNeed();
            _paymentTerms()
        }
    }
    $('.gridPhoto__item a').fancybox({
        padding: '0',
        helpers: {
            title: {
                type: 'inside'
            },
            buttons: {}
        }
    });
    (function() {
        $('.panel').on('show.bs.collapse hide.bs.collapse', function(e) {
            if (e.type == 'show') {
                $(this).addClass('active').delay(250).queue(function(next) {
                    var windowH = $(window).height() / 2;
                    var contentH = $(this).outerHeight() / 2;
                    console.log(contentH + ' + ' + windowH);
                    if (contentH >= windowH) {
                        windowH = 100;
                        contentH = 0
                    }
                    console.log(contentH + ' + ' + windowH);
                    $('html, body').stop().animate({
                        scrollTop: $(this).find('.panel-heading').offset().top - windowH + contentH
                    }, 400);
                    next()
                })
            } else {
                $(this).removeClass('active')
            }
        })
    }).call(this); // Call All
    imgSVG();
    search();
    select();
    valiForm();
    valiCareerApply();
    labelForm();
    btnShadow();
    mainBanner();
    goTo();
    gotoTop();
    checkHash();
    stickyNav();
    customers();
    parallaxBG();
    waypointEl();
    careerDetail();
    sliderWhy();
    sliderStaff();
    sliderStaffPopup();
    sliderNews();
    sliderExecutive();
    animateEffect();
    quoteFix();
    faqTabs();
    faqTabsCustome();
    methodTab();
    hoverFix();
    accordionScroll();
    fiSolution();
    $(window).scroll(function() {
        stickyNav()
    })
});
jQuery.validator.addMethod('lettersonly', function(value, element) {
    return this.optional(element) || /^[a-zA-Z\s_ÀÁÂÃÈÉÊÌÍÒÓÔÕÙÚĂĐĨŨƠàáâãèéêìíòóôõùúăđĩũơƯĂẠẢẤẦẨẪẬẮẰẲẴẶẸẺẼỀỀỂưăạảấầẩẫậắằẳẵặẹẻẽềềểỄỆỈỊỌỎỐỒỔỖỘỚỜỞỠỢỤỦỨỪễệỉịọỏốồổỗộớờởỡợụủứừỬỮỰỲỴÝỶỸửữựỳỵỷỹ]+$/i.test(value)
}, 'Vui l\xF2ng kh\xF4ng \u0111i\u1EC1n s\u1ED1 ho\u1EB7c k\xFD t\u1EF1 \u0111\u1EB7c bi\u1EC7t');
$.validator.addMethod('brithday', function(value, element) {
    return !this.optional(element) && !this.optional($(element).parent().parent().next().find('select')[0]) && !this.optional($(element).parent().parent().next().next().find('select')[0])
}, 'Vui l\xF2ng ch\u1ECDn ng\xE0y th\xE1ng n\u0103m sinh');
$.validator.addMethod('checkdate', function(value, element) {
    var d = new Date;
    var newDate = new Date(parseInt($('#applyyear').val()) + 18, $('#applymonth').val() - 1, value);
    return newDate <= d
}, 'Xin l\u1ED7i b\u1EA1n, tu\u1ED5i t\u1ED1i thi\u1EC3u \u0111\u1EC3 c\xF3 \u1EE9ng tuy\u1EC3n l\xE0 18 tu\u1ED5i');
(function() {
    jQuery.validator.addMethod('rangeWords', function(value, element, params) {
        return this.optional(element) || stripHtml(value).match(/\b\w+\b/g).length >= params[0] && value.match(/bw+b/g).length < params[1]
    }, jQuery.validator.format('Please enter between {0} and {1} words.'))
})(); // Inject YouTube API script
var tag = document.createElement('script');
tag.src = '//www.youtube.com/player_api';
var firstScriptTag = document.getElementsByTagName('script')[0];
firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);
